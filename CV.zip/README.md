CV-Tex
======
This is my CV. Commented lines are in place for one of two reasons: 1) The items is scheduled, but has not occured yet. 2) The item has already occured, but has been commented out in order to shorten the document. In the skills section, these are all skills I already possess.
